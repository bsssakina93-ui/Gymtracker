# Gym Tracker Android Project

Ye Android Studio source project hai. Is environment mein Android SDK/Gradle build tools available nahi thay, is liye is ZIP mein install-ready APK nahi hai.

## Features included in source
- Premium black + dark green interface
- Month calendar with green (gym), red (missed), brown (rest)
- Sunday weekly off label/rule
- Local persistent storage using SharedPreferences
- Google Android Auto Backup configuration for SharedPreferences
- Reminder time picker, notification permission request, alarm scheduling
- Year number based on start date; Year 1 ke baad Year 2, Year 3...
- Backup/restore Android system ke Google backup mechanism par depend karta hai; restore ko real device par test karna zaroori hai.

## APK build karne ka tareeqa
1. Computer par Android Studio install karo.
2. Is ZIP ko extract karo.
3. Android Studio mein `GymTrackerAndroid` folder open karo.
4. Gradle sync complete hone do.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK aam tor par `app/build/outputs/apk/debug/app-debug.apk` mein milega.

## Important
- Google backup tabhi chalega jab device par Google backup enabled ho aur Android system backup perform kare. Uninstall se pehle backup hona chahiye.
- Android ke naye versions exact alarms/notifications ki permissions mang sakte hain.
- Reminder receiver notification deliver karta hai; alarm sound notification channel aur device notification settings se control hota hai.
- Build aur real-device testing abhi baqi hai. Isay production-ready samajhne se pehle Android Studio mein build/test karein.
