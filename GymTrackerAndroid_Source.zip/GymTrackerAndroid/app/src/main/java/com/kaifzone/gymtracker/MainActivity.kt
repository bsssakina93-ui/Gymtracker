package com.kaifzone.gymtracker

import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

private val Black = Color(0xFF050706)
private val Panel = Color(0xFF111713)
private val Green = Color(0xFF22C55E)
private val Red = Color(0xFFEF4444)
private val Brown = Color(0xFF9A5B2E)
private val Muted = Color(0xFF9AA79D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GymTrackerApp(this) }
    }
}

@Composable
fun GymTrackerApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("gym_tracker", Context.MODE_PRIVATE) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var statuses by remember { mutableStateOf(loadStatuses(prefs)) }
    var reminderEnabled by remember { mutableStateOf(prefs.getBoolean("reminder_enabled", false)) }
    var reminderHour by remember { mutableIntStateOf(prefs.getInt("reminder_hour", 17)) }
    var reminderMinute by remember { mutableIntStateOf(prefs.getInt("reminder_minute", 0)) }
    var refresh by remember { mutableIntStateOf(0) }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val doneDates = statuses.filterValues { it == "done" }.keys
    val gymDaysTotal = doneDates.size
    val markedCount = statuses.count { it.key.startsWith("${month.year}-${month.monthValue.toString().padStart(2,'0')}") }
    val startDateString = prefs.getString("start_date", null) ?: LocalDate.now().toString().also {
        prefs.edit().putString("start_date", it).apply()
    }
    val startDate = runCatching { LocalDate.parse(startDateString) }.getOrDefault(LocalDate.now())
    val yearsElapsed = (java.time.Period.between(startDate, LocalDate.now()).years + 1).coerceAtLeast(1)
    val todayStreak = remember(statuses, selected) {
        var n = 0
        var d = selected
        while (statuses[d.toString()] == "done") { n++; d = d.minusDays(1) }
        n
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Black, surface = Panel, onBackground = Color.White,
        onSurface = Color.White, secondary = Color(0xFF86EFAC)
    )) {
        Surface(Modifier.fillMaxSize(), color = Black) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("GYM TRACKER", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("DISCIPLINE • CONSISTENCY • PROGRESS", fontSize = 10.sp, color = Muted)
                    }
                    Text("💪", fontSize = 30.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("GYM DAYS", gymDaysTotal.toString(), Green, Modifier.weight(1f))
                    StatCard("YEAR", "Year $yearsElapsed", Color(0xFFB7F7C8), Modifier.weight(1f))
                    StatCard("MARKED", markedCount.toString(), Color(0xFFF5C66B), Modifier.weight(1f))
                }
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(month.month.getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " ${month.year}", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Row {
                            Text("‹", fontSize = 28.sp, modifier = Modifier.clickable { month = month.minusMonths(1) }.padding(horizontal = 10.dp))
                            Text("›", fontSize = 28.sp, modifier = Modifier.clickable { month = month.plusMonths(1) }.padding(horizontal = 10.dp))
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        listOf("M","T","W","T","F","S","S").forEach { Text(it, color = Muted, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
                    }
                    val firstOffset = (month.atDay(1).dayOfWeek.value - 1)
                    val cells = (0 until firstOffset).map<Int, LocalDate?> { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
                    LazyVerticalGrid(columns = GridCells.Fixed(7), modifier = Modifier.height(230.dp), userScrollEnabled = false) {
                        items(cells) { date ->
                            if (date == null) Box(Modifier.padding(3.dp).size(34.dp))
                            else {
                                val status = statuses[date.toString()]
                                val isSunday = date.dayOfWeek.value == 7
                                val bg = when (status) { "done" -> Green; "missed" -> Red; "rest" -> Brown; else -> if (date == selected) Color(0xFF24432D) else Color(0xFF202722) }
                                Box(Modifier.padding(3.dp).size(34.dp).background(bg, RoundedCornerShape(10.dp))
                                    .clickable { selected = date }, contentAlignment = Alignment.Center) {
                                    Text(date.dayOfMonth.toString(), fontSize = 12.sp, color = if(status != null) Color.White else if(isSunday) Muted else Color.White, fontWeight = if(date == selected) FontWeight.Black else FontWeight.Normal)
                                }
                            }
                        }
                    }
                    Text("Green = Gym  •  Red = Missed  •  Brown = Rest  •  Sunday = Off", color = Muted, fontSize = 10.sp)
                }
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("${selected.dayOfMonth} ${selected.month.getDisplayName(TextStyle.FULL, Locale.ENGLISH)} — Check-in", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatusButton("✓ Gym gaya", Green, Modifier.weight(1f)) {
                            statuses = statuses + (selected.toString() to "done")
                            saveStatuses(prefs, statuses)
                            refresh++
                        }
                        StatusButton("✕ Miss", Red, Modifier.weight(1f)) {
                            statuses = statuses + (selected.toString() to "missed")
                            saveStatuses(prefs, statuses)
                            refresh++
                        }
                        StatusButton("Rest", Brown, Modifier.weight(1f)) {
                            statuses = statuses + (selected.toString() to "rest")
                            saveStatuses(prefs, statuses)
                            refresh++
                        }
                    }
                    Text("Weekly rule: Sunday off hai; Sunday ko missed count nahi kiya jata.", color = Muted, fontSize = 11.sp)
                }
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("Gym Reminder", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(if (reminderEnabled) "Reminder ON" else "Reminder OFF", color = if (reminderEnabled) Green else Muted)
                            Text(String.format(Locale.getDefault(), "%02d:%02d", reminderHour, reminderMinute), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(onClick = {
                            TimePickerDialog(context, { _, h, m ->
                                reminderHour = h; reminderMinute = m
                                prefs.edit().putInt("reminder_hour", h).putInt("reminder_minute", m).apply()
                                TimePickerDialog(context, { _, _, _ -> }, h, m, false).dismiss()
                                GymAlarmReceiver.scheduleNext(context)
                            }, reminderHour, reminderMinute, false).show()
                        }) { Text("Set time") }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = reminderEnabled, onCheckedChange = {
                            reminderEnabled = it
                            prefs.edit().putBoolean("reminder_enabled", it).apply()
                            if (it) {
                                if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                                    notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                                if (Build.VERSION.SDK_INT >= 31) {
                                    val am = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                                    if (!am.canScheduleExactAlarms()) context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                                }
                                GymAlarmReceiver.scheduleNext(context)
                            }
                        })
                        Text("Daily notification + alarm sound", color = Muted, fontSize = 12.sp)
                    }
                }
                Text("Year milestones keep rolling: Year 1 → Year 2 → Year 3 → ...", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(15.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun StatusButton(label: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier.height(46.dp), colors = ButtonDefaults.buttonColors(containerColor = color), contentPadding = PaddingValues(horizontal = 4.dp)) {
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

private fun loadStatuses(prefs: android.content.SharedPreferences): Map<String, String> {
    return prefs.all.filterKeys { it.startsWith("status_") }.mapKeys { it.key.removePrefix("status_") }
        .mapValues { it.value?.toString() ?: "" }
}
private fun saveStatuses(prefs: android.content.SharedPreferences, statuses: Map<String, String>) {
    val editor = prefs.edit()
    prefs.all.keys.filter { it.startsWith("status_") }.forEach { editor.remove(it) }
    statuses.forEach { (date, status) -> editor.putString("status_$date", status) }
    editor.apply()
}
