package com.kaifzone.gymtracker

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

class GymAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("gym_reminders", "Gym reminders", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Daily gym time reminders"
                enableVibration(true)
            })
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            android.app.Notification.Builder(context, "gym_reminders")
        } else {
            @Suppress("DEPRECATION")
            android.app.Notification.Builder(context)
        }.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Gym ka time ho gaya! 💪")
            .setContentText("Aaj ka check-in complete karna na bhoolna.")
            .setAutoCancel(true)
            .build()
        nm.notify(1001, notification)
        // Schedule the next reminder, but never on Sunday.
        scheduleNext(context)
    }

    companion object {
        fun scheduleNext(context: Context) {
            val prefs = context.getSharedPreferences("gym_tracker", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("reminder_enabled", false)) return
            val hour = prefs.getInt("reminder_hour", 17)
            val minute = prefs.getInt("reminder_minute", 0)
            val now = Calendar.getInstance()
            val next = Calendar.getInstance().apply {
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
                if (!after(now)) add(Calendar.DAY_OF_YEAR, 1)
                while (get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) add(Calendar.DAY_OF_YEAR, 1)
            }
            val intent = Intent(context, GymAlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(context, 1001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= 23) {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
            } else am.setExact(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) GymAlarmReceiver.scheduleNext(context)
    }
}
